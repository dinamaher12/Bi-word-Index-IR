public class Posting {
    Posting(int docId) {this.docId = docId;}
    public Posting next;
    int docId;
}
